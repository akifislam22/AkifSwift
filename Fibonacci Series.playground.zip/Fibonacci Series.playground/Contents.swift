import UIKit

func fiboseries(_ n: Int)
{

    var a = 0
    var b = 1
    print("The Fibonacci series upto the \(n)th term is:")

    for _ in 1 ... n
    {
        print (a, terminator: " ")
        let c = a + b
        a = b
        b = c
    }
    
    
}
fiboseries(12)
