import UIKit
func Floyd(_ n: Int)
{
  var c = 1
  print("Floyd's Triangle for the input \(n) is : ")
  for i in 1 ... n
   {
    for _ in 1 ... i
    {
        print(c, terminator: " ")
        c += 1
    }
    print()
   }
}
Floyd(12)


